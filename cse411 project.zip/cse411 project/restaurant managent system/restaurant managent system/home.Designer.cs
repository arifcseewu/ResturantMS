﻿namespace restaurant_managent_system
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            this.upperpanel = new System.Windows.Forms.Panel();
            this.closewindow = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sidepanel = new System.Windows.Forms.Panel();
            this.customerbtn = new System.Windows.Forms.Button();
            this.storagebtn = new System.Windows.Forms.Button();
            this.homebtn = new System.Windows.Forms.Button();
            this.orderbtn = new System.Windows.Forms.Button();
            this.bookingbtn = new System.Windows.Forms.Button();
            this.rightpanel = new System.Windows.Forms.Panel();
            this.bookingpanel = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.deletebooking = new System.Windows.Forms.PictureBox();
            this.updatebooking = new System.Windows.Forms.PictureBox();
            this.bookinglist = new System.Windows.Forms.PictureBox();
            this.addbooking = new System.Windows.Forms.PictureBox();
            this.orderpanel = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.deleteorder = new System.Windows.Forms.PictureBox();
            this.upateorder = new System.Windows.Forms.PictureBox();
            this.orderlist = new System.Windows.Forms.PictureBox();
            this.ordernow = new System.Windows.Forms.PictureBox();
            this.storagepanel = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.itemlist = new System.Windows.Forms.PictureBox();
            this.itemmanagement = new System.Windows.Forms.PictureBox();
            this.homepanel = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.customerpanel = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.managecustomer = new System.Windows.Forms.PictureBox();
            this.customerlist = new System.Windows.Forms.PictureBox();
            this.upperpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.closewindow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.sidepanel.SuspendLayout();
            this.bookingpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deletebooking)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updatebooking)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookinglist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addbooking)).BeginInit();
            this.orderpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deleteorder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upateorder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderlist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordernow)).BeginInit();
            this.storagepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemlist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemmanagement)).BeginInit();
            this.homepanel.SuspendLayout();
            this.customerpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.managecustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerlist)).BeginInit();
            this.SuspendLayout();
            // 
            // upperpanel
            // 
            this.upperpanel.BackColor = System.Drawing.SystemColors.InfoText;
            this.upperpanel.Controls.Add(this.closewindow);
            this.upperpanel.Controls.Add(this.pictureBox1);
            this.upperpanel.Controls.Add(this.label1);
            this.upperpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.upperpanel.Location = new System.Drawing.Point(0, 0);
            this.upperpanel.Name = "upperpanel";
            this.upperpanel.Size = new System.Drawing.Size(1305, 33);
            this.upperpanel.TabIndex = 0;
            // 
            // closewindow
            // 
            this.closewindow.BackColor = System.Drawing.Color.Red;
            this.closewindow.Image = global::restaurant_managent_system.Properties.Resources.greycross;
            this.closewindow.Location = new System.Drawing.Point(1278, 6);
            this.closewindow.Name = "closewindow";
            this.closewindow.Size = new System.Drawing.Size(20, 21);
            this.closewindow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.closewindow.TabIndex = 9;
            this.closewindow.TabStop = false;
            this.closewindow.Click += new System.EventHandler(this.closewindow_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poor Richard", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(25, -6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(493, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Restaurant Management System";
            // 
            // sidepanel
            // 
            this.sidepanel.BackColor = System.Drawing.Color.LightSeaGreen;
            this.sidepanel.Controls.Add(this.customerbtn);
            this.sidepanel.Controls.Add(this.storagebtn);
            this.sidepanel.Controls.Add(this.homebtn);
            this.sidepanel.Controls.Add(this.orderbtn);
            this.sidepanel.Controls.Add(this.bookingbtn);
            this.sidepanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepanel.Location = new System.Drawing.Point(0, 33);
            this.sidepanel.Name = "sidepanel";
            this.sidepanel.Size = new System.Drawing.Size(213, 585);
            this.sidepanel.TabIndex = 1;
            // 
            // customerbtn
            // 
            this.customerbtn.BackColor = System.Drawing.Color.LightSeaGreen;
            this.customerbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.customerbtn.FlatAppearance.BorderSize = 0;
            this.customerbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.customerbtn.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerbtn.Image = global::restaurant_managent_system.Properties.Resources.reservation2;
            this.customerbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.customerbtn.Location = new System.Drawing.Point(4, 139);
            this.customerbtn.Name = "customerbtn";
            this.customerbtn.Size = new System.Drawing.Size(213, 42);
            this.customerbtn.TabIndex = 8;
            this.customerbtn.Text = "   Customer Management";
            this.customerbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.customerbtn.UseVisualStyleBackColor = false;
            this.customerbtn.Click += new System.EventHandler(this.customerbtn_Click);
            // 
            // storagebtn
            // 
            this.storagebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.storagebtn.FlatAppearance.BorderSize = 0;
            this.storagebtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.storagebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.storagebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.storagebtn.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.storagebtn.Image = global::restaurant_managent_system.Properties.Resources.reservation2;
            this.storagebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.storagebtn.Location = new System.Drawing.Point(4, 280);
            this.storagebtn.Name = "storagebtn";
            this.storagebtn.Size = new System.Drawing.Size(213, 39);
            this.storagebtn.TabIndex = 7;
            this.storagebtn.Text = "   Storage Management";
            this.storagebtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.storagebtn.UseVisualStyleBackColor = true;
            this.storagebtn.Click += new System.EventHandler(this.storagebtn_Click);
            // 
            // homebtn
            // 
            this.homebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.homebtn.FlatAppearance.BorderSize = 0;
            this.homebtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.homebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.homebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homebtn.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homebtn.Image = global::restaurant_managent_system.Properties.Resources.reservation2;
            this.homebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.homebtn.Location = new System.Drawing.Point(4, 105);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(213, 39);
            this.homebtn.TabIndex = 5;
            this.homebtn.Text = "   Home";
            this.homebtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.homebtn.UseVisualStyleBackColor = true;
            this.homebtn.Click += new System.EventHandler(this.homebtn_Click);
            // 
            // orderbtn
            // 
            this.orderbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.orderbtn.FlatAppearance.BorderSize = 0;
            this.orderbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            this.orderbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.orderbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.orderbtn.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderbtn.Image = global::restaurant_managent_system.Properties.Resources.reservation2;
            this.orderbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.orderbtn.Location = new System.Drawing.Point(4, 235);
            this.orderbtn.Name = "orderbtn";
            this.orderbtn.Size = new System.Drawing.Size(213, 39);
            this.orderbtn.TabIndex = 1;
            this.orderbtn.Text = "   Ordering System";
            this.orderbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.orderbtn.UseVisualStyleBackColor = true;
            this.orderbtn.Click += new System.EventHandler(this.orderbtn_Click);
            // 
            // bookingbtn
            // 
            this.bookingbtn.BackColor = System.Drawing.Color.LightSeaGreen;
            this.bookingbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bookingbtn.FlatAppearance.BorderSize = 0;
            this.bookingbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookingbtn.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingbtn.Image = global::restaurant_managent_system.Properties.Resources.reservation2;
            this.bookingbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bookingbtn.Location = new System.Drawing.Point(4, 187);
            this.bookingbtn.Name = "bookingbtn";
            this.bookingbtn.Size = new System.Drawing.Size(213, 42);
            this.bookingbtn.TabIndex = 0;
            this.bookingbtn.Text = "   Booking System";
            this.bookingbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bookingbtn.UseVisualStyleBackColor = false;
            this.bookingbtn.Click += new System.EventHandler(this.bookingbtn_Click);
            // 
            // rightpanel
            // 
            this.rightpanel.BackColor = System.Drawing.Color.LightSeaGreen;
            this.rightpanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightpanel.Location = new System.Drawing.Point(1269, 33);
            this.rightpanel.Name = "rightpanel";
            this.rightpanel.Size = new System.Drawing.Size(36, 585);
            this.rightpanel.TabIndex = 3;
            // 
            // bookingpanel
            // 
            this.bookingpanel.BackColor = System.Drawing.Color.MediumAquamarine;
            this.bookingpanel.Controls.Add(this.label5);
            this.bookingpanel.Controls.Add(this.label4);
            this.bookingpanel.Controls.Add(this.label3);
            this.bookingpanel.Controls.Add(this.label2);
            this.bookingpanel.Controls.Add(this.deletebooking);
            this.bookingpanel.Controls.Add(this.updatebooking);
            this.bookingpanel.Controls.Add(this.bookinglist);
            this.bookingpanel.Controls.Add(this.addbooking);
            this.bookingpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookingpanel.Location = new System.Drawing.Point(213, 33);
            this.bookingpanel.Name = "bookingpanel";
            this.bookingpanel.Size = new System.Drawing.Size(1056, 585);
            this.bookingpanel.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(605, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 24);
            this.label5.TabIndex = 7;
            this.label5.Text = "Cancel Booking";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(427, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "Update booking";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(259, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "Booking list";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(88, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "Add Booking";
            // 
            // deletebooking
            // 
            this.deletebooking.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deletebooking.Image = global::restaurant_managent_system.Properties.Resources.cancel_booking;
            this.deletebooking.Location = new System.Drawing.Point(609, 153);
            this.deletebooking.Name = "deletebooking";
            this.deletebooking.Size = new System.Drawing.Size(112, 107);
            this.deletebooking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.deletebooking.TabIndex = 3;
            this.deletebooking.TabStop = false;
            this.deletebooking.Click += new System.EventHandler(this.deletebooking_Click);
            // 
            // updatebooking
            // 
            this.updatebooking.Cursor = System.Windows.Forms.Cursors.Hand;
            this.updatebooking.Image = global::restaurant_managent_system.Properties.Resources.update;
            this.updatebooking.Location = new System.Drawing.Point(431, 153);
            this.updatebooking.Name = "updatebooking";
            this.updatebooking.Size = new System.Drawing.Size(112, 107);
            this.updatebooking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.updatebooking.TabIndex = 2;
            this.updatebooking.TabStop = false;
            this.updatebooking.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // bookinglist
            // 
            this.bookinglist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bookinglist.Image = global::restaurant_managent_system.Properties.Resources.booking_list;
            this.bookinglist.Location = new System.Drawing.Point(255, 153);
            this.bookinglist.Name = "bookinglist";
            this.bookinglist.Size = new System.Drawing.Size(112, 107);
            this.bookinglist.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bookinglist.TabIndex = 1;
            this.bookinglist.TabStop = false;
            this.bookinglist.Click += new System.EventHandler(this.bookinglist_Click);
            // 
            // addbooking
            // 
            this.addbooking.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addbooking.Image = global::restaurant_managent_system.Properties.Resources.booknow;
            this.addbooking.Location = new System.Drawing.Point(90, 153);
            this.addbooking.Name = "addbooking";
            this.addbooking.Size = new System.Drawing.Size(112, 107);
            this.addbooking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.addbooking.TabIndex = 0;
            this.addbooking.TabStop = false;
            this.addbooking.Click += new System.EventHandler(this.addbooking_Click);
            // 
            // orderpanel
            // 
            this.orderpanel.Controls.Add(this.label9);
            this.orderpanel.Controls.Add(this.label8);
            this.orderpanel.Controls.Add(this.label7);
            this.orderpanel.Controls.Add(this.label6);
            this.orderpanel.Controls.Add(this.deleteorder);
            this.orderpanel.Controls.Add(this.upateorder);
            this.orderpanel.Controls.Add(this.orderlist);
            this.orderpanel.Controls.Add(this.ordernow);
            this.orderpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.orderpanel.Location = new System.Drawing.Point(213, 33);
            this.orderpanel.Name = "orderpanel";
            this.orderpanel.Size = new System.Drawing.Size(1056, 585);
            this.orderpanel.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(736, 260);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 24);
            this.label9.TabIndex = 7;
            this.label9.Text = "Cancel Order";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(536, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 24);
            this.label8.TabIndex = 6;
            this.label8.Text = "Update Order";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(337, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 24);
            this.label7.TabIndex = 5;
            this.label7.Text = "Order List";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Poor Richard", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(135, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 24);
            this.label6.TabIndex = 4;
            this.label6.Text = "Order Now";
            // 
            // deleteorder
            // 
            this.deleteorder.Image = global::restaurant_managent_system.Properties.Resources.ordercancel;
            this.deleteorder.Location = new System.Drawing.Point(727, 128);
            this.deleteorder.Name = "deleteorder";
            this.deleteorder.Size = new System.Drawing.Size(134, 115);
            this.deleteorder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.deleteorder.TabIndex = 3;
            this.deleteorder.TabStop = false;
            this.deleteorder.Click += new System.EventHandler(this.deleteorder_Click);
            // 
            // upateorder
            // 
            this.upateorder.Image = global::restaurant_managent_system.Properties.Resources.addorder;
            this.upateorder.Location = new System.Drawing.Point(523, 129);
            this.upateorder.Name = "upateorder";
            this.upateorder.Size = new System.Drawing.Size(134, 115);
            this.upateorder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.upateorder.TabIndex = 2;
            this.upateorder.TabStop = false;
            this.upateorder.Click += new System.EventHandler(this.upateorder_Click);
            // 
            // orderlist
            // 
            this.orderlist.Image = global::restaurant_managent_system.Properties.Resources.orderlist;
            this.orderlist.Location = new System.Drawing.Point(314, 128);
            this.orderlist.Name = "orderlist";
            this.orderlist.Size = new System.Drawing.Size(134, 115);
            this.orderlist.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.orderlist.TabIndex = 1;
            this.orderlist.TabStop = false;
            this.orderlist.Click += new System.EventHandler(this.orderlist_Click);
            // 
            // ordernow
            // 
            this.ordernow.Image = global::restaurant_managent_system.Properties.Resources.order_now;
            this.ordernow.Location = new System.Drawing.Point(115, 129);
            this.ordernow.Name = "ordernow";
            this.ordernow.Size = new System.Drawing.Size(134, 115);
            this.ordernow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ordernow.TabIndex = 0;
            this.ordernow.TabStop = false;
            this.ordernow.Click += new System.EventHandler(this.ordernow_Click);
            // 
            // storagepanel
            // 
            this.storagepanel.Controls.Add(this.label12);
            this.storagepanel.Controls.Add(this.label11);
            this.storagepanel.Controls.Add(this.itemlist);
            this.storagepanel.Controls.Add(this.itemmanagement);
            this.storagepanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.storagepanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.storagepanel.Location = new System.Drawing.Point(213, 33);
            this.storagepanel.Name = "storagepanel";
            this.storagepanel.Size = new System.Drawing.Size(1056, 585);
            this.storagepanel.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(159, 393);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 24);
            this.label12.TabIndex = 5;
            this.label12.Text = "Storage List";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(401, 393);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(191, 24);
            this.label11.TabIndex = 4;
            this.label11.Text = "Storage Management";
            // 
            // itemlist
            // 
            this.itemlist.Image = global::restaurant_managent_system.Properties.Resources.menulist;
            this.itemlist.Location = new System.Drawing.Point(77, 128);
            this.itemlist.Name = "itemlist";
            this.itemlist.Size = new System.Drawing.Size(254, 262);
            this.itemlist.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.itemlist.TabIndex = 2;
            this.itemlist.TabStop = false;
            this.itemlist.Click += new System.EventHandler(this.itemlist_Click);
            // 
            // itemmanagement
            // 
            this.itemmanagement.Image = global::restaurant_managent_system.Properties.Resources.Database_4;
            this.itemmanagement.Location = new System.Drawing.Point(367, 128);
            this.itemmanagement.Name = "itemmanagement";
            this.itemmanagement.Size = new System.Drawing.Size(262, 262);
            this.itemmanagement.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.itemmanagement.TabIndex = 1;
            this.itemmanagement.TabStop = false;
            this.itemmanagement.Click += new System.EventHandler(this.itemmanagement_Click);
            // 
            // homepanel
            // 
            this.homepanel.Controls.Add(this.label10);
            this.homepanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.homepanel.Location = new System.Drawing.Point(213, 33);
            this.homepanel.Name = "homepanel";
            this.homepanel.Size = new System.Drawing.Size(1056, 585);
            this.homepanel.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "label10";
            // 
            // customerpanel
            // 
            this.customerpanel.Controls.Add(this.label14);
            this.customerpanel.Controls.Add(this.label13);
            this.customerpanel.Controls.Add(this.managecustomer);
            this.customerpanel.Controls.Add(this.customerlist);
            this.customerpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customerpanel.Location = new System.Drawing.Point(213, 33);
            this.customerpanel.Name = "customerpanel";
            this.customerpanel.Size = new System.Drawing.Size(1056, 585);
            this.customerpanel.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(362, 352);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(206, 26);
            this.label14.TabIndex = 12;
            this.label14.Text = "Customer Management";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(156, 352);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 26);
            this.label13.TabIndex = 11;
            this.label13.Text = "Customer List";
            // 
            // managecustomer
            // 
            this.managecustomer.Image = global::restaurant_managent_system.Properties.Resources.cus;
            this.managecustomer.Location = new System.Drawing.Point(367, 165);
            this.managecustomer.Name = "managecustomer";
            this.managecustomer.Size = new System.Drawing.Size(195, 175);
            this.managecustomer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.managecustomer.TabIndex = 1;
            this.managecustomer.TabStop = false;
            this.managecustomer.Click += new System.EventHandler(this.managecustomer_Click);
            // 
            // customerlist
            // 
            this.customerlist.Image = global::restaurant_managent_system.Properties.Resources.cus_list;
            this.customerlist.Location = new System.Drawing.Point(117, 165);
            this.customerlist.Name = "customerlist";
            this.customerlist.Size = new System.Drawing.Size(182, 175);
            this.customerlist.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.customerlist.TabIndex = 0;
            this.customerlist.TabStop = false;
            this.customerlist.Click += new System.EventHandler(this.customerlist_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumAquamarine;
            this.ClientSize = new System.Drawing.Size(1305, 618);
            this.Controls.Add(this.customerpanel);
            this.Controls.Add(this.orderpanel);
            this.Controls.Add(this.bookingpanel);
            this.Controls.Add(this.storagepanel);
            this.Controls.Add(this.homepanel);
            this.Controls.Add(this.rightpanel);
            this.Controls.Add(this.sidepanel);
            this.Controls.Add(this.upperpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "home";
            this.Load += new System.EventHandler(this.home_Load);
            this.upperpanel.ResumeLayout(false);
            this.upperpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.closewindow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.sidepanel.ResumeLayout(false);
            this.bookingpanel.ResumeLayout(false);
            this.bookingpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deletebooking)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updatebooking)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookinglist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addbooking)).EndInit();
            this.orderpanel.ResumeLayout(false);
            this.orderpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deleteorder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upateorder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderlist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordernow)).EndInit();
            this.storagepanel.ResumeLayout(false);
            this.storagepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemlist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemmanagement)).EndInit();
            this.homepanel.ResumeLayout(false);
            this.homepanel.PerformLayout();
            this.customerpanel.ResumeLayout(false);
            this.customerpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.managecustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerlist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel upperpanel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel sidepanel;
        private System.Windows.Forms.Button bookingbtn;
        private System.Windows.Forms.Button orderbtn;

        private System.Windows.Forms.Panel rightpanel;
        private System.Windows.Forms.Panel bookingpanel;
        private System.Windows.Forms.PictureBox deletebooking;
        private System.Windows.Forms.PictureBox updatebooking;
        private System.Windows.Forms.PictureBox bookinglist;
        private System.Windows.Forms.PictureBox addbooking;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel orderpanel;
        private System.Windows.Forms.PictureBox ordernow;
        private System.Windows.Forms.PictureBox deleteorder;
        private System.Windows.Forms.PictureBox upateorder;
        private System.Windows.Forms.PictureBox orderlist;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button storagebtn;
        private System.Windows.Forms.Button homebtn;
        private System.Windows.Forms.PictureBox closewindow;
        private System.Windows.Forms.Button customerbtn;
        private System.Windows.Forms.Panel storagepanel;
        private System.Windows.Forms.Panel customerpanel;
        private System.Windows.Forms.PictureBox customerlist;
        private System.Windows.Forms.PictureBox managecustomer;
        private System.Windows.Forms.PictureBox itemmanagement;
        private System.Windows.Forms.PictureBox itemlist;
        private System.Windows.Forms.Panel homepanel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
    }
}