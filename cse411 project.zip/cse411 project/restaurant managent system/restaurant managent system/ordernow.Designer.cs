﻿namespace restaurant_managent_system
{
    partial class ordernow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.itemnametxt = new System.Windows.Forms.TextBox();
            this.itemquantitytxt = new System.Windows.Forms.TextBox();
            this.addcartbtn = new System.Windows.Forms.Button();
            this.itemgridview = new System.Windows.Forms.DataGridView();
            this.itemtblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.generateorderidbtn = new System.Windows.Forms.Button();
            this.orderidtxt = new System.Windows.Forms.TextBox();
            this.itempricetxt = new System.Windows.Forms.TextBox();
            this.carttblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.allsearchchk = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.itemsearchcmb = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.itemtypetxt = new System.Windows.Forms.TextBox();
            this.itemidtxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.refreshbtn = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.totalitemtxt = new System.Windows.Forms.TextBox();
            this.totalquantitytxt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.daddresschk = new System.Windows.Forms.CheckBox();
            this.daddresstxt = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.grandtotalbtn = new System.Windows.Forms.Button();
            this.totalbilltxt = new System.Windows.Forms.TextBox();
            this.cartremovebtn = new System.Windows.Forms.Button();
            this.citemidtxt = new System.Windows.Forms.TextBox();
            this.cartgridview = new System.Windows.Forms.DataGridView();
            this.carttblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dDatetxt = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.ordergridview = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordertblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantdbDataSet16 = new restaurant_managent_system.restaurantdbDataSet16();
            this.confirmorderbtn = new System.Windows.Forms.Button();
            this.ordertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.closebtn = new System.Windows.Forms.PictureBox();
            this.carttblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.customerloadbtn = new System.Windows.Forms.Button();
            this.customeraddresstxt = new System.Windows.Forms.RichTextBox();
            this.customerphonetxt = new System.Windows.Forms.TextBox();
            this.customeremailtxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.customernametxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.customeridtxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.itemtblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ordertblTableAdapter1 = new restaurant_managent_system.restaurantdbDataSet16TableAdapters.ordertblTableAdapter();
            this.restaurantdbDataSet18 = new restaurant_managent_system.restaurantdbDataSet18();
            this.itemtblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.itemtblTableAdapter1 = new restaurant_managent_system.restaurantdbDataSet18TableAdapters.itemtblTableAdapter();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.restaurantdbDataSet19 = new restaurant_managent_system.restaurantdbDataSet19();
            this.carttblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.carttblTableAdapter2 = new restaurant_managent_system.restaurantdbDataSet19TableAdapters.carttblTableAdapter();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.itemgridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemtblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cartgridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ordergridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordertblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantdbDataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordertblBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.closebtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemtblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantdbDataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemtblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantdbDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // itemnametxt
            // 
            this.itemnametxt.Location = new System.Drawing.Point(303, 77);
            this.itemnametxt.Name = "itemnametxt";
            this.itemnametxt.Size = new System.Drawing.Size(194, 20);
            this.itemnametxt.TabIndex = 1;
            // 
            // itemquantitytxt
            // 
            this.itemquantitytxt.Location = new System.Drawing.Point(303, 111);
            this.itemquantitytxt.Name = "itemquantitytxt";
            this.itemquantitytxt.Size = new System.Drawing.Size(194, 20);
            this.itemquantitytxt.TabIndex = 3;
            // 
            // addcartbtn
            // 
            this.addcartbtn.Location = new System.Drawing.Point(19, 389);
            this.addcartbtn.Name = "addcartbtn";
            this.addcartbtn.Size = new System.Drawing.Size(478, 39);
            this.addcartbtn.TabIndex = 4;
            this.addcartbtn.Text = "ADD TO CART";
            this.addcartbtn.UseVisualStyleBackColor = true;
            this.addcartbtn.Click += new System.EventHandler(this.addcartbtn_Click);
            // 
            // itemgridview
            // 
            this.itemgridview.AutoGenerateColumns = false;
            this.itemgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.itemgridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.itemgridview.DataSource = this.itemtblBindingSource2;
            this.itemgridview.Location = new System.Drawing.Point(19, 143);
            this.itemgridview.Name = "itemgridview";
            this.itemgridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.itemgridview.Size = new System.Drawing.Size(478, 236);
            this.itemgridview.TabIndex = 5;
            this.itemgridview.MouseClick += new System.Windows.Forms.MouseEventHandler(this.itemgridview_MouseClick);
            // 
            // itemtblBindingSource
            // 
            this.itemtblBindingSource.DataMember = "itemtbl";
            // 
            // generateorderidbtn
            // 
            this.generateorderidbtn.Location = new System.Drawing.Point(19, 13);
            this.generateorderidbtn.Name = "generateorderidbtn";
            this.generateorderidbtn.Size = new System.Drawing.Size(278, 23);
            this.generateorderidbtn.TabIndex = 7;
            this.generateorderidbtn.Text = "Generate Order ID";
            this.generateorderidbtn.UseVisualStyleBackColor = true;
            this.generateorderidbtn.Click += new System.EventHandler(this.generateorderidbtn_Click);
            // 
            // orderidtxt
            // 
            this.orderidtxt.Location = new System.Drawing.Point(303, 14);
            this.orderidtxt.Name = "orderidtxt";
            this.orderidtxt.Size = new System.Drawing.Size(194, 20);
            this.orderidtxt.TabIndex = 8;
            // 
            // itempricetxt
            // 
            this.itempricetxt.Location = new System.Drawing.Point(122, 111);
            this.itempricetxt.Name = "itempricetxt";
            this.itempricetxt.Size = new System.Drawing.Size(89, 20);
            this.itempricetxt.TabIndex = 9;
            // 
            // carttblBindingSource
            // 
            this.carttblBindingSource.DataMember = "carttbl";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.allsearchchk);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.itemsearchcmb);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.itemtypetxt);
            this.groupBox1.Controls.Add(this.itemidtxt);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.generateorderidbtn);
            this.groupBox1.Controls.Add(this.itempricetxt);
            this.groupBox1.Controls.Add(this.orderidtxt);
            this.groupBox1.Controls.Add(this.itemnametxt);
            this.groupBox1.Controls.Add(this.itemquantitytxt);
            this.groupBox1.Controls.Add(this.addcartbtn);
            this.groupBox1.Controls.Add(this.itemgridview);
            this.groupBox1.Location = new System.Drawing.Point(12, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(514, 442);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // allsearchchk
            // 
            this.allsearchchk.AutoSize = true;
            this.allsearchchk.Location = new System.Drawing.Point(472, 48);
            this.allsearchchk.Name = "allsearchchk";
            this.allsearchchk.Size = new System.Drawing.Size(15, 14);
            this.allsearchchk.TabIndex = 20;
            this.allsearchchk.UseVisualStyleBackColor = true;
            this.allsearchchk.CheckedChanged += new System.EventHandler(this.allsearchchk_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(434, 43);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 22);
            this.label19.TabIndex = 19;
            this.label19.Text = "All";
            // 
            // itemsearchcmb
            // 
            this.itemsearchcmb.DataSource = this.itemtblBindingSource;
            this.itemsearchcmb.DisplayMember = "itemType";
            this.itemsearchcmb.FormattingEnabled = true;
            this.itemsearchcmb.Location = new System.Drawing.Point(366, 43);
            this.itemsearchcmb.Name = "itemsearchcmb";
            this.itemsearchcmb.Size = new System.Drawing.Size(62, 21);
            this.itemsearchcmb.TabIndex = 18;
            this.itemsearchcmb.SelectedIndexChanged += new System.EventHandler(this.itemsearchcmb_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(303, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 22);
            this.label11.TabIndex = 17;
            this.label11.Text = "Search:";
            // 
            // itemtypetxt
            // 
            this.itemtypetxt.Location = new System.Drawing.Point(122, 77);
            this.itemtypetxt.Name = "itemtypetxt";
            this.itemtypetxt.Size = new System.Drawing.Size(89, 20);
            this.itemtypetxt.TabIndex = 16;
            // 
            // itemidtxt
            // 
            this.itemidtxt.Location = new System.Drawing.Point(122, 42);
            this.itemidtxt.Name = "itemidtxt";
            this.itemidtxt.Size = new System.Drawing.Size(175, 20);
            this.itemidtxt.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(16, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 22);
            this.label10.TabIndex = 14;
            this.label10.Text = "Item ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 22);
            this.label4.TabIndex = 13;
            this.label4.Text = "Unit Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(217, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 22);
            this.label3.TabIndex = 12;
            this.label3.Text = "Quantity:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(235, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 22);
            this.label2.TabIndex = 11;
            this.label2.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 22);
            this.label1.TabIndex = 10;
            this.label1.Text = "Item Type:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.refreshbtn);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.totalitemtxt);
            this.groupBox2.Controls.Add(this.totalquantitytxt);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.daddresschk);
            this.groupBox2.Controls.Add(this.daddresstxt);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.grandtotalbtn);
            this.groupBox2.Controls.Add(this.totalbilltxt);
            this.groupBox2.Controls.Add(this.cartremovebtn);
            this.groupBox2.Controls.Add(this.citemidtxt);
            this.groupBox2.Controls.Add(this.cartgridview);
            this.groupBox2.Location = new System.Drawing.Point(546, 126);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(557, 349);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // refreshbtn
            // 
            this.refreshbtn.Location = new System.Drawing.Point(10, 19);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(128, 24);
            this.refreshbtn.TabIndex = 34;
            this.refreshbtn.Text = "Refresh Cart";
            this.refreshbtn.UseVisualStyleBackColor = true;
            this.refreshbtn.Click += new System.EventHandler(this.refreshbtn_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(462, 272);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 22);
            this.label18.TabIndex = 33;
            this.label18.Text = "Total bill";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(344, 272);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(123, 22);
            this.label17.TabIndex = 32;
            this.label17.Text = "Total Quantity";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(248, 272);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 22);
            this.label16.TabIndex = 31;
            this.label16.Text = "Total Item";
            // 
            // totalitemtxt
            // 
            this.totalitemtxt.Location = new System.Drawing.Point(252, 240);
            this.totalitemtxt.Multiline = true;
            this.totalitemtxt.Name = "totalitemtxt";
            this.totalitemtxt.Size = new System.Drawing.Size(86, 26);
            this.totalitemtxt.TabIndex = 30;
            // 
            // totalquantitytxt
            // 
            this.totalquantitytxt.Location = new System.Drawing.Point(354, 240);
            this.totalquantitytxt.Multiline = true;
            this.totalquantitytxt.Name = "totalquantitytxt";
            this.totalquantitytxt.Size = new System.Drawing.Size(106, 26);
            this.totalquantitytxt.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 264);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(155, 22);
            this.label15.TabIndex = 28;
            this.label15.Text = "Delivery Address:";
            // 
            // daddresschk
            // 
            this.daddresschk.AutoSize = true;
            this.daddresschk.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.daddresschk.Location = new System.Drawing.Point(167, 269);
            this.daddresschk.Name = "daddresschk";
            this.daddresschk.Size = new System.Drawing.Size(15, 14);
            this.daddresschk.TabIndex = 27;
            this.daddresschk.UseVisualStyleBackColor = true;
            this.daddresschk.CheckedChanged += new System.EventHandler(this.daddresschk_CheckedChanged);
            // 
            // daddresstxt
            // 
            this.daddresstxt.Location = new System.Drawing.Point(10, 297);
            this.daddresstxt.Name = "daddresstxt";
            this.daddresstxt.Size = new System.Drawing.Size(236, 44);
            this.daddresstxt.TabIndex = 26;
            this.daddresstxt.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 236);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(217, 22);
            this.label13.TabIndex = 25;
            this.label13.Text = "Use Customer Address As";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(144, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 22);
            this.label12.TabIndex = 24;
            this.label12.Text = "Item ID:";
            // 
            // grandtotalbtn
            // 
            this.grandtotalbtn.Location = new System.Drawing.Point(252, 297);
            this.grandtotalbtn.Name = "grandtotalbtn";
            this.grandtotalbtn.Size = new System.Drawing.Size(298, 44);
            this.grandtotalbtn.TabIndex = 23;
            this.grandtotalbtn.Text = "Grand Total";
            this.grandtotalbtn.UseVisualStyleBackColor = true;
            this.grandtotalbtn.Click += new System.EventHandler(this.grandtotalbtn_Click);
            // 
            // totalbilltxt
            // 
            this.totalbilltxt.Location = new System.Drawing.Point(466, 240);
            this.totalbilltxt.Multiline = true;
            this.totalbilltxt.Name = "totalbilltxt";
            this.totalbilltxt.Size = new System.Drawing.Size(85, 26);
            this.totalbilltxt.TabIndex = 22;
            // 
            // cartremovebtn
            // 
            this.cartremovebtn.Location = new System.Drawing.Point(354, 24);
            this.cartremovebtn.Name = "cartremovebtn";
            this.cartremovebtn.Size = new System.Drawing.Size(197, 21);
            this.cartremovebtn.TabIndex = 3;
            this.cartremovebtn.Text = "REMOVE FROM CART";
            this.cartremovebtn.UseVisualStyleBackColor = true;
            this.cartremovebtn.Click += new System.EventHandler(this.cartremovebtn_Click);
            // 
            // citemidtxt
            // 
            this.citemidtxt.Location = new System.Drawing.Point(225, 24);
            this.citemidtxt.Name = "citemidtxt";
            this.citemidtxt.Size = new System.Drawing.Size(123, 20);
            this.citemidtxt.TabIndex = 2;
            // 
            // cartgridview
            // 
            this.cartgridview.AutoGenerateColumns = false;
            this.cartgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cartgridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.cartgridview.DataSource = this.carttblBindingSource3;
            this.cartgridview.Location = new System.Drawing.Point(6, 50);
            this.cartgridview.Name = "cartgridview";
            this.cartgridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.cartgridview.Size = new System.Drawing.Size(545, 183);
            this.cartgridview.TabIndex = 0;
            this.cartgridview.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cartgridview_MouseClick);
            // 
            // carttblBindingSource2
            // 
            this.carttblBindingSource2.DataMember = "carttbl";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dDatetxt);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.ordergridview);
            this.groupBox3.Controls.Add(this.confirmorderbtn);
            this.groupBox3.Location = new System.Drawing.Point(12, 481);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1091, 222);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            // 
            // dDatetxt
            // 
            this.dDatetxt.Location = new System.Drawing.Point(130, 21);
            this.dDatetxt.Name = "dDatetxt";
            this.dDatetxt.Size = new System.Drawing.Size(197, 20);
            this.dDatetxt.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 22);
            this.label14.TabIndex = 25;
            this.label14.Text = "Delivery Date:";
            // 
            // ordergridview
            // 
            this.ordergridview.AutoGenerateColumns = false;
            this.ordergridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ordergridview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.ordergridview.DataSource = this.ordertblBindingSource1;
            this.ordergridview.Location = new System.Drawing.Point(341, 19);
            this.ordergridview.Name = "ordergridview";
            this.ordergridview.Size = new System.Drawing.Size(743, 185);
            this.ordergridview.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "orderId";
            this.dataGridViewTextBoxColumn1.HeaderText = "orderId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "customerId";
            this.dataGridViewTextBoxColumn2.HeaderText = "customerId";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "deliveryDate";
            this.dataGridViewTextBoxColumn3.HeaderText = "deliveryDate";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "deliveryAddress";
            this.dataGridViewTextBoxColumn4.HeaderText = "deliveryAddress";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "totalItem";
            this.dataGridViewTextBoxColumn5.HeaderText = "totalItem";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "totalQuantity";
            this.dataGridViewTextBoxColumn6.HeaderText = "totalQuantity";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "totalBill";
            this.dataGridViewTextBoxColumn7.HeaderText = "totalBill";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // ordertblBindingSource1
            // 
            this.ordertblBindingSource1.DataMember = "ordertbl";
            this.ordertblBindingSource1.DataSource = this.restaurantdbDataSet16;
            // 
            // restaurantdbDataSet16
            // 
            this.restaurantdbDataSet16.DataSetName = "restaurantdbDataSet16";
            this.restaurantdbDataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // confirmorderbtn
            // 
            this.confirmorderbtn.Location = new System.Drawing.Point(6, 67);
            this.confirmorderbtn.Name = "confirmorderbtn";
            this.confirmorderbtn.Size = new System.Drawing.Size(329, 137);
            this.confirmorderbtn.TabIndex = 5;
            this.confirmorderbtn.Text = "CONFIRM ORDER";
            this.confirmorderbtn.UseVisualStyleBackColor = true;
            this.confirmorderbtn.Click += new System.EventHandler(this.confirmorderbtn_Click);
            // 
            // ordertblBindingSource
            // 
            this.ordertblBindingSource.DataMember = "ordertbl";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.closebtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1115, 27);
            this.panel1.TabIndex = 13;
            // 
            // closebtn
            // 
            this.closebtn.Image = global::restaurant_managent_system.Properties.Resources.close_red;
            this.closebtn.Location = new System.Drawing.Point(1087, 0);
            this.closebtn.Name = "closebtn";
            this.closebtn.Size = new System.Drawing.Size(28, 26);
            this.closebtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.closebtn.TabIndex = 0;
            this.closebtn.TabStop = false;
            this.closebtn.Click += new System.EventHandler(this.closebtn_Click);
            // 
            // carttblBindingSource1
            // 
            this.carttblBindingSource1.DataMember = "carttbl";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.customerloadbtn);
            this.groupBox4.Controls.Add(this.customeraddresstxt);
            this.groupBox4.Controls.Add(this.customerphonetxt);
            this.groupBox4.Controls.Add(this.customeremailtxt);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.customernametxt);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.customeridtxt);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(546, 33);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(557, 87);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            // 
            // customerloadbtn
            // 
            this.customerloadbtn.Location = new System.Drawing.Point(481, 13);
            this.customerloadbtn.Name = "customerloadbtn";
            this.customerloadbtn.Size = new System.Drawing.Size(75, 71);
            this.customerloadbtn.TabIndex = 23;
            this.customerloadbtn.Text = "Load";
            this.customerloadbtn.UseVisualStyleBackColor = true;
            this.customerloadbtn.Click += new System.EventHandler(this.customerloadbtn_Click);
            // 
            // customeraddresstxt
            // 
            this.customeraddresstxt.Location = new System.Drawing.Point(84, 40);
            this.customeraddresstxt.Name = "customeraddresstxt";
            this.customeraddresstxt.Size = new System.Drawing.Size(209, 44);
            this.customeraddresstxt.TabIndex = 22;
            this.customeraddresstxt.Text = "";
            // 
            // customerphonetxt
            // 
            this.customerphonetxt.Location = new System.Drawing.Point(364, 64);
            this.customerphonetxt.Name = "customerphonetxt";
            this.customerphonetxt.Size = new System.Drawing.Size(110, 20);
            this.customerphonetxt.TabIndex = 21;
            // 
            // customeremailtxt
            // 
            this.customeremailtxt.Location = new System.Drawing.Point(364, 38);
            this.customeremailtxt.Name = "customeremailtxt";
            this.customeremailtxt.Size = new System.Drawing.Size(110, 20);
            this.customeremailtxt.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(299, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 22);
            this.label9.TabIndex = 19;
            this.label9.Text = "Phone:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 22);
            this.label8.TabIndex = 18;
            this.label8.Text = "Address:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(299, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 22);
            this.label7.TabIndex = 17;
            this.label7.Text = "Email:";
            // 
            // customernametxt
            // 
            this.customernametxt.Location = new System.Drawing.Point(364, 13);
            this.customernametxt.Name = "customernametxt";
            this.customernametxt.Size = new System.Drawing.Size(110, 20);
            this.customernametxt.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(299, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 22);
            this.label6.TabIndex = 15;
            this.label6.Text = "Name:";
            // 
            // customeridtxt
            // 
            this.customeridtxt.Location = new System.Drawing.Point(118, 13);
            this.customeridtxt.Name = "customeridtxt";
            this.customeridtxt.Size = new System.Drawing.Size(175, 20);
            this.customeridtxt.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 22);
            this.label5.TabIndex = 12;
            this.label5.Text = "CustomerID:";
            // 
            // itemtblBindingSource1
            // 
            this.itemtblBindingSource1.DataMember = "itemtbl";
            // 
            // ordertblTableAdapter1
            // 
            this.ordertblTableAdapter1.ClearBeforeFill = true;
            // 
            // restaurantdbDataSet18
            // 
            this.restaurantdbDataSet18.DataSetName = "restaurantdbDataSet18";
            this.restaurantdbDataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemtblBindingSource2
            // 
            this.itemtblBindingSource2.DataMember = "itemtbl";
            this.itemtblBindingSource2.DataSource = this.restaurantdbDataSet18;
            // 
            // itemtblTableAdapter1
            // 
            this.itemtblTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "itemId";
            this.dataGridViewTextBoxColumn8.HeaderText = "itemId";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "itemName";
            this.dataGridViewTextBoxColumn9.HeaderText = "itemName";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "itemType";
            this.dataGridViewTextBoxColumn10.HeaderText = "itemType";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "itemPrice";
            this.dataGridViewTextBoxColumn11.HeaderText = "itemPrice";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // restaurantdbDataSet19
            // 
            this.restaurantdbDataSet19.DataSetName = "restaurantdbDataSet19";
            this.restaurantdbDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // carttblBindingSource3
            // 
            this.carttblBindingSource3.DataMember = "carttbl";
            this.carttblBindingSource3.DataSource = this.restaurantdbDataSet19;
            // 
            // carttblTableAdapter2
            // 
            this.carttblTableAdapter2.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "itemId";
            this.dataGridViewTextBoxColumn12.HeaderText = "itemId";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "itemName";
            this.dataGridViewTextBoxColumn13.HeaderText = "itemName";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "itemPrice";
            this.dataGridViewTextBoxColumn14.HeaderText = "itemPrice";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "itemQuantity";
            this.dataGridViewTextBoxColumn15.HeaderText = "itemQuantity";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "totalPrice";
            this.dataGridViewTextBoxColumn16.HeaderText = "totalPrice";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // ordernow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1115, 715);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ordernow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ordernow";
            this.Load += new System.EventHandler(this.ordernow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.itemgridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemtblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cartgridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ordergridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordertblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantdbDataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordertblBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.closebtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemtblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantdbDataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemtblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantdbDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carttblBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox itemnametxt;
        private System.Windows.Forms.TextBox itemquantitytxt;
        private System.Windows.Forms.Button addcartbtn;
        private System.Windows.Forms.DataGridView itemgridview;
        private restaurantdbDataSet1 restaurantdbDataSet1;
        private System.Windows.Forms.BindingSource itemtblBindingSource;
        private restaurantdbDataSet1TableAdapters.itemtblTableAdapter itemtblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button generateorderidbtn;
        private System.Windows.Forms.TextBox orderidtxt;
        private System.Windows.Forms.TextBox itempricetxt;
        private restaurantdbDataSet3 restaurantdbDataSet3;
        private System.Windows.Forms.BindingSource carttblBindingSource;
        private restaurantdbDataSet3TableAdapters.carttblTableAdapter carttblTableAdapter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView ordergridview;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource carttblBindingSource1;
        private restaurantdbDataSet4 restaurantdbDataSet4;
        private System.Windows.Forms.BindingSource carttblBindingSource2;
        private restaurantdbDataSet4TableAdapters.carttblTableAdapter carttblTableAdapter1;
        private System.Windows.Forms.Button cartremovebtn;
        private System.Windows.Forms.TextBox citemidtxt;
        private System.Windows.Forms.DataGridView cartgridview;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemPriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button confirmorderbtn;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button customerloadbtn;
        private System.Windows.Forms.RichTextBox customeraddresstxt;
        private System.Windows.Forms.TextBox customerphonetxt;
        private System.Windows.Forms.TextBox customeremailtxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox customernametxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox customeridtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox closebtn;
        private System.Windows.Forms.BindingSource itemtblBindingSource1;
        private System.Windows.Forms.TextBox totalbilltxt;
        private System.Windows.Forms.Button grandtotalbtn;
        private System.Windows.Forms.TextBox itemidtxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox itemtypetxt;
        private System.Windows.Forms.ComboBox itemsearchcmb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private restaurantdbDataSet5 restaurantdbDataSet5;
        private System.Windows.Forms.BindingSource ordertblBindingSource;
        private restaurantdbDataSet5TableAdapters.ordertblTableAdapter ordertblTableAdapter;
        private System.Windows.Forms.CheckBox daddresschk;
        private System.Windows.Forms.RichTextBox daddresstxt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalItemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalBillDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker dDatetxt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox totalitemtxt;
        private System.Windows.Forms.TextBox totalquantitytxt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button refreshbtn;
        private System.Windows.Forms.CheckBox allsearchchk;
        private System.Windows.Forms.Label label19;
        private restaurantdbDataSet16 restaurantdbDataSet16;
        private System.Windows.Forms.BindingSource ordertblBindingSource1;
        private restaurantdbDataSet16TableAdapters.ordertblTableAdapter ordertblTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private restaurantdbDataSet18 restaurantdbDataSet18;
        private System.Windows.Forms.BindingSource itemtblBindingSource2;
        private restaurantdbDataSet18TableAdapters.itemtblTableAdapter itemtblTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private restaurantdbDataSet19 restaurantdbDataSet19;
        private System.Windows.Forms.BindingSource carttblBindingSource3;
        private restaurantdbDataSet19TableAdapters.carttblTableAdapter carttblTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
    }
}